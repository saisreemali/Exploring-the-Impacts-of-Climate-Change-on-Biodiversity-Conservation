// JavaScript for form validation
document.getElementById('contactForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form submission

  var name = document.getElementById('name').value;
  var email = document.getElementById('email').value;
  var subject = document.getElementById('subject').value;
  var message = document.getElementById('message').value;

  // Check if any field is empty
  if (name === '' || email === '' || subject === '' || message === '') {
    alert('Please fill in all fields');
    return;
  }

  // Check email format
  var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if (!email.match(emailRegex)) {
    alert('Please enter a valid email address');
    return;
  }

  // All validations pass, submit the form
  document.getElementById('contactForm').submit();
  // Log the form data to the console
  console.log("Submitted Details:");
  console.log("Name: " + name);
  console.log("Email: " + email);
  console.log("Subject: " + subject);
  console.log("Message: " + message);

  // Clear form fields
  document.getElementById("contactForm").reset();

 
});
