window.addEventListener('DOMContentLoaded', function() {
  // Get the registration form element
  var form = document.getElementById('registrationForm');

  // Add event listener for form submission
  form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Perform form validation
    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var address = document.getElementById('address').value;
    var email = document.getElementById('email').value;

    // Check if required fields are empty
    if (firstName === '' || lastName === '' || address === '' || email === '') {
      alert('Please fill in all required fields.');
      return;
    }

    // Validate email format
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert('Please enter a valid email address.');
      return;
    }

    // Form is valid, submit the form
    form.submit();
  });
});

